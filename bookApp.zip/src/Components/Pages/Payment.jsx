import React from 'react'

function Payment() {
  return (
    <div>
      <h1>Payment GateWay...</h1>
    </div>
  )
}

export default Payment;
