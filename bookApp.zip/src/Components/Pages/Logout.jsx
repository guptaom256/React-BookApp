import React from 'react'
import Navbar from './Navbar'

function Logout() {
  return (
    <div>
      <Navbar></Navbar>
      <h1>Logout</h1>
    </div>
  )
}

export default Logout
